#include "GrS.h"

MatrixXf opt_selectcell(ArrayXXf& cell)
{
	int n = cell.rows() > cell.cols() ? cell.rows() : cell.cols();
	int power = pow(2, n);
	MatrixXf standby_point(power, n);
	MatrixXf _index(n, power);
	//ÿһά�Ȼ���2����
	for (int i = 1; i <= n; i++)
	{
		int a = 1;
		int k = pow(2, n - i);
		int t = 2 * k - 1;
		for (int j = 1; j <= power; j++)
		{
			_index(i - 1, j - 1) = (a <= k) ? 1 : 2;
			a = (a > t) ? 1 : a + 1;
		}
	}

	for (int i = 0; i < n; i++)
	{
		for (int j = 0; j < power; j++)
		{
			//��ȡ����,һ��һ��ѡȡ
			standby_point(j, i) = cell(i, int(_index(i, j) - 1));
		}
	}

	return standby_point;
}