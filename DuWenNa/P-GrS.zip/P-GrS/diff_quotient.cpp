#include"GrS.h"

inline double _max(const double x, const double y)
{
	return x > y ? x : y;
}

//matrix_f_value��״Ϊ2^n�У�һ��
double diff_quotient(const MatrixXf& matrix_f_value)
{
	double L0 = 0.1;//�������Ľ��ʼ��
	int n = matrix_f_value.cols();
	double *delta = new double[n];
	for (int i = 0; i < n - 1; ++i)
	{
		delta[i] = (matrix_f_value(i + 1) - matrix_f_value(i)) / _max(matrix_f_value(i + 1), matrix_f_value(i));
	}
	double max_factor = 0;
	for (int i = 0; i < n - 1; i++)
	{
		if (max_factor < delta[i])
			max_factor = delta[i];
	}
	L0 = _max(L0, max_factor);
	return L0;
}