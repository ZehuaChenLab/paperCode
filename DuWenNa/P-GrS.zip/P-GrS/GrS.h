﻿#pragma once
#include<iostream>
#include"Eigen/Core"
#include<vector>
#include<cmath>
#include<algorithm>
#include<iomanip>
#include<omp.h>
#include"time.h"
using namespace Eigen;

//   Ժ   ,  Ҫ    Ͷ  n  ά  (2^n  n  )     2^n  1  2^n У     
//     Ժ    ķ   ֵ  һ        
MatrixXf Sphere(const MatrixXf& x);
MatrixXf StyblinskiTang(const MatrixXf& x);
MatrixXf Sargan(const MatrixXf& x);
MatrixXf X_2(const MatrixXf& x);
MatrixXf Ackley(const MatrixXf& x);
MatrixXf Brown(const MatrixXf& x);
MatrixXf Mishra02(const MatrixXf& x);
MatrixXf Rosenbrock(const MatrixXf& x);
MatrixXf Schwefel01(const MatrixXf& x);
MatrixXf Cocgpf(const MatrixXf& x);
MatrixXf Schwefel20(const MatrixXf& x);
MatrixXf Schwefel21(const MatrixXf& x);
MatrixXf Schwefel22(const MatrixXf& x);
MatrixXf Himmelblau(const MatrixXf& x);
MatrixXf Mishra07(const MatrixXf& x);
MatrixXf DevilliersGlasser01(const MatrixXf& x);
MatrixXf DevilliersGlasser02(const MatrixXf& x);
MatrixXf Adjiman(const MatrixXf& x);
MatrixXf Alpine01(const MatrixXf& x);
MatrixXf BartelsConn(const MatrixXf& x);
MatrixXf Beale(const MatrixXf& x);
MatrixXf Bird(const MatrixXf& x);
MatrixXf Bohachevsky(const MatrixXf& x);
MatrixXf BoxBetts(const MatrixXf& x);
MatrixXf Brent(const MatrixXf& x);
MatrixXf Bukin04(const MatrixXf& x);
MatrixXf Bukin06(const MatrixXf& x);
MatrixXf Colville(const MatrixXf& x);
MatrixXf Cube(const MatrixXf& x);
MatrixXf Easom(const MatrixXf& x);
MatrixXf Eggcrate(const MatrixXf& x);
MatrixXf ElAttarVidyasagarDutta(const MatrixXf& x);
MatrixXf Exp2(const MatrixXf& x);
MatrixXf Exponential(const MatrixXf& x);
MatrixXf FreudensteinRoth(const MatrixXf& x);
MatrixXf Giunta(const MatrixXf& x);
MatrixXf GoldsteinPrice(const MatrixXf& x);
MatrixXf Gulf(const MatrixXf& x);
MatrixXf Hosaki(const MatrixXf& x);
MatrixXf JennrichSampson(const MatrixXf& x);
MatrixXf Leon(const MatrixXf& x);
MatrixXf Matyas(const MatrixXf& x);
MatrixXf McCormick(const MatrixXf& x);
MatrixXf MieleCantrell(const MatrixXf& x);
MatrixXf Mishra05(const MatrixXf& x);
MatrixXf Mishra08(const MatrixXf& x);
MatrixXf Mishra09(const MatrixXf& x);
MatrixXf Mishra10(const MatrixXf& x);
MatrixXf Pathological(const MatrixXf& x);
MatrixXf Paviani(const MatrixXf& x);
MatrixXf Powell(const MatrixXf& x);
MatrixXf Price01(const MatrixXf& x);
MatrixXf Price02(const MatrixXf& x);
MatrixXf Price03(const MatrixXf& x);
MatrixXf Price04(const MatrixXf& x);
MatrixXf Chichinadze(const MatrixXf& x);
MatrixXf Quadratic(const MatrixXf& x);
MatrixXf Quintic(const MatrixXf& x);
MatrixXf Ripple01(const MatrixXf& x);
MatrixXf Ripple25(const MatrixXf& x);
MatrixXf RotatedEllipse01(const MatrixXf& x);
MatrixXf RotatedEllipse02(const MatrixXf& x);
MatrixXf Salomon(const MatrixXf& x);
MatrixXf Schaffer01(const MatrixXf& x);
MatrixXf Schaffer02(const MatrixXf& x);
MatrixXf Schwefel04(const MatrixXf& x);
MatrixXf Schwefel06(const MatrixXf& x);
MatrixXf Schwefel36(const MatrixXf& x);
MatrixXf SixHumpCamel(const MatrixXf& x);
MatrixXf TestTubeHolder(const MatrixXf& x);
MatrixXf ThreeHumpCamel(const MatrixXf& x);
MatrixXf Treccani(const MatrixXf& x);
MatrixXf Trefethen(const MatrixXf& x);
MatrixXf Trid(const MatrixXf& x);
MatrixXf Trigonometric02(const MatrixXf& x);
MatrixXf Ursem01(const MatrixXf& x);
MatrixXf Ursem03(const MatrixXf& x);
MatrixXf Ursem04(const MatrixXf& x);
MatrixXf UrsemWaves(const MatrixXf& x);
MatrixXf VenterSobiezcczanskiSobieski(const MatrixXf& x);
MatrixXf Wavy(const MatrixXf& x);
MatrixXf WayburnSeader01(const MatrixXf& x);
MatrixXf WayburnSeader02(const MatrixXf& x);
MatrixXf Wolfe(const MatrixXf& x);
MatrixXf XinSheYang02(const MatrixXf& x);
MatrixXf XinSheYang03(const MatrixXf& x);
MatrixXf XinSheYang04(const MatrixXf& x);
MatrixXf Zettl(const MatrixXf& x);
MatrixXf Zirilli(const MatrixXf& x);
MatrixXf CarromTable(const MatrixXf& x);
MatrixXf CrossInTray(const MatrixXf& x);
MatrixXf HolderTable(const MatrixXf& x);
MatrixXf Five_Uneven_Peak(const MatrixXf& x);
MatrixXf Bukin02(const MatrixXf& x);
MatrixXf CosineMixture(const MatrixXf& x);
MatrixXf CrossLegTable(const MatrixXf& x);
MatrixXf DeckkersAarts(const MatrixXf& x);
MatrixXf Dolan(const MatrixXf& x);
MatrixXf Griewank(const MatrixXf& x);
MatrixXf Mishra03(const MatrixXf& x);
MatrixXf Mishra04(const MatrixXf& x);
MatrixXf Mishra06(const MatrixXf& x);
MatrixXf Qing(const MatrixXf& x);
MatrixXf RosenbrockModified(const MatrixXf& x);
MatrixXf Schaffer03(const MatrixXf& x);
MatrixXf Schaffer04(const MatrixXf& x);
MatrixXf Trigonometric01(const MatrixXf& x);
MatrixXf Zacharov(const MatrixXf& x);
MatrixXf Alpine02(const MatrixXf& x);
MatrixXf Branin01(const MatrixXf& x);
MatrixXf Branin02(const MatrixXf& x);
MatrixXf Deb01(const MatrixXf& x);
MatrixXf Deb02(const MatrixXf& x);
MatrixXf Hansen(const MatrixXf& x);
MatrixXf Mishra01(const MatrixXf& x);
MatrixXf Mishra11(const MatrixXf& x);
MatrixXf Parsopoulos(const MatrixXf& x);
MatrixXf Rana(const MatrixXf& x);
MatrixXf Shubert01(const MatrixXf& x);
MatrixXf Shubert03(const MatrixXf& x);
MatrixXf Shubert04(const MatrixXf& x);
MatrixXf SineEnvelope(const MatrixXf& x);
MatrixXf DixonPrice(const MatrixXf& x);
MatrixXf EggHolder(const MatrixXf& x);
MatrixXf Hartmann3(const MatrixXf& x);
MatrixXf Hartmann6(const MatrixXf& x);
MatrixXf Himmelblauyuan(const MatrixXf& x);
MatrixXf Langermann(const MatrixXf& x);
MatrixXf Pinter(const MatrixXf& x);
MatrixXf Schwefel02(const MatrixXf& x);
MatrixXf Shekel05(const MatrixXf& x);
MatrixXf Shekel07(const MatrixXf& x);
MatrixXf Shekel10(const MatrixXf& x);
MatrixXf Watson(const MatrixXf& x);
MatrixXf Weierstrass(const MatrixXf& x);
MatrixXf Whitley(const MatrixXf& x);
MatrixXf Xinsheyang01(const MatrixXf& x);
MatrixXf Zimmerman(const MatrixXf& x);
float sign_func(float x);
//'bounds' is bounds for variables(format: [a1 b1;a2 b2;...;an,bn]).;
void GrS(MatrixXf& bounds);

//Calculation for the coordinates of the center points
MatrixXf selectcell(ArrayXXf& cell);

// Calculate the difference quotient
double diff_quotient(const MatrixXf& matrix_f_value);

double sum_for_section(const MatrixXf& d);

void log_multi(const MatrixXf& C1, MatrixXf& d, std::vector<int>& p, int& k, double& time);

void multilayer(const MatrixXf& C1, MatrixXf& d, std::vector<int>& p, int& k, double& time);

void original_multi(const MatrixXf& C1, MatrixXf& d, std::vector<int>& p, int& k, double& time);

MatrixXf subpartition(MatrixXf C, MatrixXf S);

MatrixXf opt_selectcell(ArrayXXf& cell);

MatrixXf f_selectcell(ArrayXXf& cell);

MatrixXf selectcell_100(ArrayXXf& cell);

MatrixXf selectcell_75(ArrayXXf& cell);

MatrixXf selectcell_50(ArrayXXf& cell);


MatrixXf selectcell_25(ArrayXXf& cell);

MatrixXf selectcell_10(ArrayXXf& cell);

MatrixXf f_subpartition(MatrixXf C, MatrixXf S);
//75->4->2
void var_GrS(MatrixXf& bounds);
//4->2
void var_ini_GrS(MatrixXf& bounds);

void var_multi(const MatrixXf& C1, MatrixXf& d, std::vector<int>& p, int& k, double& time);

bool apart(const MatrixXf C, MatrixXf S);







































