#include "GrS.h"
extern MatrixXf(*func_)(const MatrixXf& x);

void var_GrS(MatrixXf& bounds)
{
	int n = bounds.rows(); //ά��
	MatrixXf lower(1, n);//ÿ��ά�ȵ��½�
	MatrixXf upper(1, n);//ÿ��ά�ȵ��Ͻ�
	MatrixXf dimension_length(1, n); //���䳤��
	//ÿһά�Ȼ��ֵı���
	int init_partition = 2;
	lower = bounds.col(0);
	upper = bounds.col(1);
	dimension_length = upper - lower;
	//d��2��һ��
	MatrixXf d = dimension_length / init_partition;
	//���ڶ˵㴦�Ҽ�ֵ
	lower = lower + d / 2;
	upper = upper - d / 2;
	ArrayXXf cell(n, 100);
	MatrixXf C1;
	switch (n)
	{
	case 1:
	case 2:
		for (int i = 0; i < n; i++)
			cell.row(i) = ArrayXf::LinSpaced(100, lower(i), upper(i));
		C1 = selectcell_100(cell); //ѡ��������
		break;
	default:
		for (int i = 0; i < n; i++)
			cell.row(i) = ArrayXf::LinSpaced(4, lower(i), upper(i));
		C1 = f_selectcell(cell);
		break;
	}
	MatrixXf f_value = func_(C1);
	std::vector<int> p;
	int k = 0;
	double time = 0;
	var_multi(C1, d, p, k, time);
	//log_multi(C1, d, p, k, time);
	std::cout << "total iteration time: " << time << std::endl;
}



