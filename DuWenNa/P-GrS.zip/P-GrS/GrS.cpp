#include "GrS.h"
extern MatrixXf(*func_)(const MatrixXf& x);

void GrS(MatrixXf& bounds)
{
	//std::cout << "Please input the thread num:";
	//int thread_num;
	//std::cin >> thread_num;
	int n = bounds.rows(); //ά��
	MatrixXf lower(1, n);//ÿ��ά�ȵ��½�
	MatrixXf upper(1, n);//ÿ��ά�ȵ��Ͻ�
	MatrixXf dimension_length(1, n); //���䳤��
	//ÿһά�Ȼ��ֵı���
	int init_partition = 2;
	lower = bounds.col(0);
	upper = bounds.col(1);
	dimension_length = upper - lower;
	//d��2��һ��
	MatrixXf d = dimension_length / init_partition;
	//���ڶ˵㴦�Ҽ�ֵ
	lower = lower + d / 2;
	upper = upper - d / 2;
	ArrayXXf cell(n, 2);
	for (int i = 0; i < n; i++)
		cell.row(i) = ArrayXf::LinSpaced(init_partition, lower(i), upper(i));
	MatrixXf C1 = selectcell(cell); //ѡ��������
	MatrixXf f_value = func_(C1);
	std::vector<int> p;
	int k = 0;
	double time = 0;
	//multilayer(C1, d, p, k, time);
	log_multi(C1, d, p, k, time);
	std::cout << "total iteration time: " << time << std::endl;
}



