#include"GrS.h"

extern MatrixXf(*func_)(const MatrixXf& x);
//p�����¼����Լ������������
void original_multi(const MatrixXf& C1, MatrixXf& d, std::vector<int>& p, int& k, double& time)
{
	clock_t start_sub, end_sub, start_call, end_call, start_product, end_product, start_iter, end_iter;
	bool flag = true;
	double min_gap;
	double distance = sum_for_section(d);
	//2^n��1��
	MatrixXf f_value = func_(C1);
	int dimen = C1.cols();//��ȡά��
	if (dimen >= 5)
	{
		min_gap = 2e-3;
	}
	else
	{
		min_gap = 5e-4;
	}
	//num�ǵ�ĸ���,num = 2^n
	//����2^n���㣨һ����nά���������Ӧ2^n������ֵ
	int num = f_value.cols();
	double f_min = f_value.minCoeff();
	double f_min_pre = f_min;
	double L = diff_quotient(f_value);
	if (L >= 100)
		L = 50;
	double err1 = L * distance;
	double err2 = distance;
	std::cout << "initial L:" << L << std::endl;
	f_min = f_value.minCoeff();
	double scope = f_min + err1;   //v + delta * L ,�����仯��
	//�������б�׼�����¼������
	for (int i = 0; i < num; i++)
	{
		if (f_value(i) <= scope)
			p.push_back(i);
	}
	k = p.size();
	ArrayXXf C_plus(k, dimen);  //��һ��C
	for (int i = 0; i < k; i++)
	{
		C_plus.row(i) = C1.row(p[i]);
	}
	C_plus.matrix();
	int layer = 0;
	while (flag)
	{
		p.clear();
		d /= 2;
		distance = sum_for_section(d);
		err1 = distance * L, err2 = distance;
		ArrayXXf S(2, dimen);
		for (int i = 0; i < dimen; i++)
			S.col(i) = ArrayXf::LinSpaced(2, -d(i) / 2, d(i) / 2);
		S.matrix();
		start_sub = clock();
		//C_plus ��״Ϊ��ĸ�����k���� 2^n�У�n��
		C_plus = subpartition(C_plus, S);
		end_sub = clock();

		start_call = clock();
		f_value = func_(C_plus);
		end_call = clock();
		num = f_value.cols();

		start_product = clock();
		f_min = f_value.minCoeff();
		if (fabs(f_min - f_min_pre) < min_gap)
			flag = false;
		f_min_pre = f_min;
		end_product = clock();

		f_min = f_value.minCoeff();
		scope = f_min + err1;
		k = 0;
		for (int i = 0; i < num; i++)
		{
			if (f_value(i) <= scope)
				p.push_back(i);
		}
		k = p.size();
		start_iter = clock();
		MatrixXf temp_arg(k, dimen);
		for (int i = 0; i < k; i++)
		{
			temp_arg.row(i) = C_plus.row(p[i]);
		}
		C_plus = temp_arg;
		end_iter = clock();
		layer++;
		L = (layer >= 3 ? L * 1.2 : L);
		time += (double)(end_sub - start_sub + end_call - start_call + end_product - start_product + end_iter - start_iter) / 1000;
		{
			std::cout << "------------------------------" << std::endl;
			std::cout << "layer:" << layer << std::endl;
			std::cout << "min: " << f_min << "     " << "pre min :" << f_min_pre << std::endl;
			std::cout << "err1:" << err1 << '\t' << "err2:" << err2 << std::endl;
			std::cout << "distance:" << distance << '\t' << std::endl;
			std::cout << "L:" << L << std::endl;
			std::cout << "time of subpartition:" << (double)(end_sub - start_sub) / 1000 << std::endl;
			std::cout << "time of call test function:" << (double)(end_call - start_call) / 1000 << std::endl;
			std::cout << "time of find minimum and product operation:" << (double)(end_product - start_product) / 1000 << std::endl;
			std::cout << "time of update C:" << (double)(end_iter - start_iter) / 1000 << std::endl;
			std::cout << "number of points are satisfiable:" << k << std::endl;
			std::cout << "---d---" << std::endl << d << std::endl;
			std::cout << "------------------------------" << std::endl;
		}
	}
	p.clear();
	f_value = func_(C_plus);
	f_min = f_value.minCoeff();
	int loc;
	for (int i = 0; i < f_value.cols(); i++)
	{
		if (f_value(i) == f_min)
		{
			p.push_back(i);
			loc = i;
			break;
		}
	}
	for (int i = 0; i < f_value.cols(); i++)
	{
		if (i != loc && f_value(i) <= f_min + 1e-4 && apart(C_plus.row(loc), C_plus.row(i)))
		{
			p.push_back(i);
		}
	}
	k = p.size();
	for (int i = 0; i < k; i++)
	{
		std::cout << "------------------------------" << std::endl;
		std::cout << "Total iteration:" << layer << std::endl;
		std::cout << "Coordinates of points:" << std::endl;
		std::cout << C_plus.row(p[i]) << std::setw(10) << std::endl;
		std::cout << "The minimum value of function:" << std::endl;
		std::cout << f_value(p[i]) << std::setw(10) << std::endl;
		std::cout << "------------------------------" << std::endl;
	}
	std::cout << "The number of final points is :" << k << std::endl;
}